
// 14 Simular ingreso hasta que el usuario escriba "salir" //

let entradas = ["hola", "salir"];
let i = 0;
let entrada;

do {
    entrada = entradas[i];
    console.log("Ingresaste: ", entrada)
    i++;
} while (entrada.toLowerCase() !== "salir");

console.log("Programa Finalizado")