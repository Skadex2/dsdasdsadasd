// 02 Verificar si una edad esta entre 18 y 65 años (Inclusive)//
let edad = 12;

if (edad >= 18 && edad <=65){
    console.log("edad valida para trabajar");

} else{
    console.log("Edad fuera del rango laboral");
}