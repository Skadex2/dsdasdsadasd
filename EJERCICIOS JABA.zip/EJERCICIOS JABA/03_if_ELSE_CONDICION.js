// 03 Verificar si un numero es par o impar //

let numero=7;

if(numero % 2 === 0 ){
    console.log("PAR");
} else {
    console.log("El numero es impar");
}