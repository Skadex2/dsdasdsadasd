// 09 mostrar la tbgla de muultiplicar del 7//

for (let i = 1; i <= 12; i++) {
    console.log(`7 x ${i} = ${7 * i}`);
    }