// 04 Clasificar a una persona segun su edad //

let edad = 12;

if (edad >= 0){
    if (edad < 12) {
        console.log("El usuario es un niño");
    } else if (edad < 18) {
        console.log("El usuario es un adolescente");
    } else {
        console.log("El usuario es un Adulto");
    }
} else {
    console.log ("Edad no valida");
}