// 08 mostrar los umero edl 1 al 10 //
for (let i = 0; i <= 100; i+=5) {
    console.log(i);
}