// 10 Mostrar los numeros pares del 1 al 20 usando while//

let i = 1;

while (i <= 20) {
if (i % 2 === 0) {
console.log(i);
}
i++;
}