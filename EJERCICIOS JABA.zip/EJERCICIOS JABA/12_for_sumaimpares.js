// 12 Sumar los números impares del 1 al 100 //

let suma = 0;

for (let i = 1; i <= 100; i += 2) {
suma += i;
}

console.log("Suma de impares del 1 al 100:", suma);