// 15 Recorrer un array de productos y mostrarlos //

let productos = ["Pan", "Leche", "Huevos", "Café", "AZucar", "Pan"];

for (let i = 0; i < productos.length; i++) {
console.log(`Producto ${i + 1}:`, productos[i]);
}