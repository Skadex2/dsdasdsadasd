// 01 Determimar numero positivo, negativo o cero//
let numero = 0;

if (numero > 0){
    console.log("El numero es positivo");
}

if (numero < 0){
    console.log("EL numero es negativo")
}

if (numero == 0){
    console.log("EL numero es cero")
}